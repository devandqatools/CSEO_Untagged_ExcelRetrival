select invAss.RecId,COALESCE(csedapp.nameDesc,nceseapp.nameDesc) as AppName,
grpLkp.Grp,subgrpLkp.SubGrp,priorLkp.Priority,assActLkp.AssActivity,assStaLkp.AssStatus,assMtdLkp.AssMethod,invAss.EstStDate, 
invAss.EstEndDate, invAss.DateStarted, invAss.DateCompletedfrom [dbo].[InvAssessments] invAss left join [dbo].[InvAppData] appData 
on invAss.RecId = appData.RecId and appData.isDeleted = 0left join [dbo].[CSEAppSTData] csedapp 
on appData.RecId = csedapp.RecId left join [dbo].[NonCSEAppSTData] nceseapp 
on appData.RecId = nceseapp.RecId left join [dbo].[GroupLookups] grpLkp 
on appData.GrpId = grpLkp.GrpId and grpLkp.isDelete = 0left join [dbo].[SubGroups] subgrpLkp 
on appData.SubGrpId = subgrpLkp.SubGrpId and subgrpLkp.isDelete = 0left join [dbo].[PriorityLookups] priorLkp 
on appData.PriId = priorLkp.PriorityId and priorLkp.isDeleted = 0left join [dbo].[AssessmentActivityLookups] assActLkp 
on invAss.AssActivityId = assActLkp.AssActivityId and assActLkp.isDeleted = 0left join [dbo].[AssessmentStatusLookups] assStaLkp 
on invAss.AssStatusId = assStaLkp.AssStatusId and assStaLkp.isDeleted = 0left join [dbo].[AssessmentMethodLookups] assMtdLkp 
on invAss.AssMethodId = assMtdLkp.AssMethodId and assMtdLkp.isDeleted = 0 where MONTH(invAss.DateCompleted) = MONTH(getDate())-1 and YEAR(invAss.DateCompleted) = YEAR(getDate()) andinvAss.isDeleted= 0 order by invAss.RecId asc


select * from  [dbo].[CSEAppSTData]
select COALESCE(cseAppData.NameDesc,nceseapp.nameDesc) as NameDesc,COALESCE(cseAppData.SubGrpAccLead,nceseapp.SubGrpAccLead) as SubGrpAccLead,COALESCE(cseAppData.EngOnwer,nceseapp.EngOnwer) as EngOnwer,COALESCE(subgrpLkp.SubGrp,'') as SubGrp,COALESCE(priLkps.Priority,'') as Priority,COALESCE(opsLkps.OpsStatus,'') as OpsStatus from  [dbo].[InvAppData] invAppData 
left join [dbo].[CSEAppSTData] cseAppData on cseAppData.RecID = invAppData.RecID
left join [dbo].[NonCSEAppSTData] nceseapp on invAppData.RecID = nceseapp.RecId 
left join [dbo].[SubGroups] subgrpLkp on subgrpLkp.SubGrpId	 = invAppData.SubGrpId and subgrpLkp.isDeleted = 0
left join [dbo].[PriorityLookups] priLkps on priLkps.PriorityId = invAppData.PriId and priLkps.isDeleted = 0 
left join [dbo].[OpsStatusLookups] opsLkps on opsLkps.OpsStatusId = invAppData.OpsStatusId and opsLkps.isDeleted = 0  where invAppData.RecId= '509'

select * from [NonCSEAppSTData] where RecID = '509'